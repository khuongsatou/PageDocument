<?php
    echo 'Đây là nội dung trả về';

?>