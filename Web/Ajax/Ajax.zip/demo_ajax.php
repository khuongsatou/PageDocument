<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
    <script>
        function load_ajax(){
            var xmlhttp;
            if(window.XMLHttpRequet){
                xmlhttp = new XMLHttpRequest();
            }else{
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }

            xmlhttp.onreadystatechange = function(){
                if(xmlhttp.readyState==4 && xmlhttp.status ==200){
                    documment.getElementById("result").innerHTML = xmlhtmp.responseText;
                }
            }
        }

    </script>
<body>
    <?php   
    



    ?>
</body>

</html>